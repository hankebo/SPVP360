from torch import nn
import numpy as np
import torch as th
from data_test import VRVideo
import torchvision.transforms as tf
from torch.utils import data as tdata
import torch.optim as optim
from torch.autograd import Variable
from argparse import ArgumentParser
from fire import Fire
from tqdm import trange, tqdm
import visdom
import time
import os
import copy
from  sp_net  import Final ,flownet, Cnn ,Cnn_map,flo_map # spherical_unet
from sconv.module import SphereMSE  #SphericalConv 
from torch.utils.data import Dataset
from torch.utils.data import DataLoader
from PIL import Image
 

 
def minmaxscaler1(img_map):
    
    img_map=np.maximum(img_map, 0)
    min=th.zeros(img_map.size()[0],1, img_map.size()[2])
    max=th.zeros(img_map.size()[0],1,img_map.size()[2])
    for i11 in range(img_map.size()[0]):
     for i111 in range(img_map.size()[2]):
      min[i11,0,i111]=th.min(img_map[i11,0,i111,:])
      max[i11,0,i111]=th.max(img_map[i11,0,i111,:])
      img_map[i11,0,i111,:]= (img_map[i11,0,i111,:]-min[i11,0,i111])/(max[i11,0,i111]-min[i11,0,i111]+0.00001)
    
    
    return  img_map

    
def minmaxscaler(img_map):
    img_map=np.maximum(img_map, 0)
    min=th.zeros(img_map.size()[0],1,1)
    max=th.zeros(img_map.size()[0],1,1)
    for i11 in range(img_map.size()[0]):
      min[i11]=th.min(img_map[i11])
      max[i11]=th.max(img_map[i11])
      img_map[i11]= (img_map[i11]-min[i11])/(max[i11]-min[i11]+0.00001)
      
   
    #img_map=abs(img_map)
    #min=np.amin(img_map)
    #max=np.amax(img_map)
    #img_map= (img_map-min)/(max-min+0.00001)
    #np.where(img_map > 0.5,  img_map, 0)
    #img_map=np.maximum(img_map, 0.5 )
    return  img_map 

def Accuracy_sig(he_map):
    block_h=14
    block_w=14
    min=th.zeros(he_map.size()[0],1,1)
    max=th.zeros(he_map.size()[0],1,1)
    for i11 in range(he_map.size()[0]):
      min[i11]=th.min(he_map[i11])
      max[i11]=th.max(he_map[i11])
      he_map[i11]= (he_map[i11]-min[i11])/(max[i11]-min[i11]+0.00001)
      
    a_min=th.zeros(he_map.size()[0],1,int(56/block_h)*int(112/block_w))   
    he_map_sig=th.zeros(int(56/block_h)*int(112/block_w),he_map.size()[0])
    he_map_sig=he_map_sig.int()
    for i2 in range(he_map.size()[0]):
      blocks=1
      for i3 in range(int(56/block_h)):
         for i4 in range(int(112/block_w)):          
           a_min[i2,:,i3*4+i4]=(he_map[i2,:,i3*block_h:(i3+1)*block_h-1, i4*block_w:(i4+1)*block_w-1]).mean()
           if a_min[i2, 0,i3*4+i4] >= 0.2:
             he_map_sig[i3*4+i4,i2]=blocks
           blocks= blocks+1
    
    he_map_sig= th.transpose(he_map_sig,1,0) 
    return he_map_sig
   
def Accuracy_sig1(he_map):
    block_h=14
    block_w=14
    min=th.zeros(he_map.size()[0],1,1)
    max=th.zeros(he_map.size()[0],1,1)
    for i11 in range(he_map.size()[0]):
      min[i11]=th.min(he_map[i11])
      max[i11]=th.max(he_map[i11])
      he_map[i11]= (he_map[i11]-min[i11])/(max[i11]-min[i11]+0.00001)
    a_min=th.zeros(he_map.size()[0],1,int(56/block_h)*int(112/block_w))   
    he_map_sig=th.zeros(int(56/block_h)*int(112/block_w),he_map.size()[0])
    he_map_sig=he_map_sig.int()
    
    for i2 in range(he_map.size()[0]):
      blocks=1
      for i3 in range(int(56/block_h)):
         for i4 in range(int(112/block_w)):          
           a_min[i2,:,i3*4+i4]=(he_map[i2,:,i3*block_h:(i3+1)*block_h-1, i4*block_w:(i4+1)*block_w-1]).mean()
           if a_min[i2, 0,i3*4+i4] != 0:
             he_map_sig[i3*4+i4,i2]=blocks
           blocks= blocks+1
    #he_map_sig = th.gt(a_min,0.2)
             #he_map_sig[i2,0,i3*4+i4]==1
    he_map_sig= th.transpose(he_map_sig,1,0)
    return he_map_sig    

def dif(liA,liB):
    #求交集的两种方式
    #liA=liA .numpy().tolist()
    #liB= 
    count_num=0
    reta_sum=[]
    retb_sum=[]
    reta_p=th.zeros(liA.size()[0])
    reta_r=th.zeros(liB.size()[0])
    retA=[]
    for i111 in range(liA.size()[0]):
      
      #retA=  
      retA.append(list(set(liA[i111]).intersection(set(liB[i111]))))
      retA[i111] = th.from_numpy(np.array(retA[i111]))
      
      reta_sum.append(liA.size()[1]-liA[i111].numpy().tolist().count(count_num)+1)
      
      retb_sum.append(liB.size()[1]-liB[i111].numpy().tolist().count(count_num)+1)
      reta_p[i111]=((retA[i111].size()[0])/ reta_sum[i111]+0.0001)
      reta_r[i111]=((retA[i111].size()[0])/ retb_sum[i111]+0.0001)
      #reta_p[i111]= th.from_numpy(np.array(reta_p[i111]))
      #reta_r[i111]= th.from_numpy(np.array(reta_p[i111]))
      #retA = [j11 for j11 in liA[i111] if j11 in liB[i111]]
   # retB = list(set(listA).intersection(set(listB)))
     
    return retA,reta_p,reta_r


log_dir='model_final5_1_1.pth.tar'

#log_file = open('C:/Users/Admin/Desktop/HL/Saliency-detection-in-360-video-master/saliency5/final.txt', 'w+')   
#log_file1 = open('C:/Users/Admin/Desktop/HL/Saliency-detection-in-360-video-master/saliency5/out_sig1.txt', 'w+')
#log_file2= open('C:/Users/Admin/Desktop/HL/Saliency-detection-in-360-video-master/saliency5/g_sig1.txt', 'w+')
#log_file3= open('C:/Users/Admin/Desktop/HL/Saliency-detection-in-360-video-master/saliency5/jiao_sig1.txt', 'w+')
#log_file4= open('C:/Users/Admin/Desktop/HL/Saliency-detection-in-360-video-master/saliency5/out_accrreact11.txt', 'w+')
#log_file5= open('C:/Users/Admin/Desktop/HL/Saliency-detection-in-360-video-master/saliency5/val_out1.txt', 'w+')
#log_file6= open('C:/Users/Admin/Desktop/HL/Saliency-detection-in-360-video-master/saliency5/train_epoch_loss1.txt', 'w+')

os.environ['CUDA_VISIBLE_DEVICES'] ='3'
def test(
        root='C:/Users/Admin/Desktop/HL/360video_our_all', #'E:/360_VRvideo','F:/360VRvideo', #"C:\Users\Admin\Desktop\HL\360_Saliency"
        bs=14, #28
        lr=0.01 ,
        epochs=178,
        clear_cache=False,
        plot_server='http://127.0.0.1',
        plot_port=8097,
        save_interval=1,
        resume=True ,  #True False
        start_epoch=0,
        exp_name='final',
        step_size=10,
        test_mode=True#False
):
    # pynvml.nvmlInit()
    viz = visdom.Visdom(server=plot_server, port=plot_port, env=exp_name)

    transform = tf.Compose([
        tf.Resize((112, 224)), #128, 256  #shuffle=true 数据集打乱     
        tf.ToTensor()
    ])
    dataset = VRVideo( root,112, 224,frame_interval=5, cache_gt= True, transform=transform, gaussian_sigma=np.pi/20, kernel_rad=np.pi/7)
    print(dataset)  #128, 256,
    if clear_cache:
        dataset.clear_cache()
    loader = tdata.DataLoader(dataset, batch_size=bs, shuffle= False , num_workers=0, pin_memory=False )#True 
    print(type(loader))
    
    #th.backends.cudnn.enabled = False
    model_cnn=Cnn()
    #model_cnnmap=Cnn_map()
    model_flo=flownet()
    #model_flomap=flo_map()
    model = Final()  
    
    model_cnn= nn.DataParallel(model_cnn).cuda()
    #model_cnnmap=nn.DataParallel(model_cnnmap).cuda()
    model_flo=nn.DataParallel(model_flo).cuda()
   #model_flomap=nn.DataParallel(model_flomap).cuda()
    model =nn.DataParallel(model).cuda()
    
    
   

    #model_cnn=model_cnn.cuda()
    #model_cnnmap=model_cnnmap.cuda()
    #model_flo=model_flo.cuda()
    #model_flomap=model_flomap.cuda()
    #model =model.cuda()
    
    optimizer = optim.SGD(model.parameters(), lr, momentum=0.9, weight_decay=1e-5)  #优化器
    criterion = SphereMSE(56, 112).float().cuda()    #损失函数128,256
    #if resume:
        
        #ckpt = th.load('model_final1.pth.tar' ) #'ckpt-' + exp_name +'-latest.pth.tar'
        #model.load_state_dict(ckpt['model_state_dict'])   #'''应用到网络结构中''''state_dict'
        #start_epoch = ckpt['epoch']
   
    if resume:
        checkpoint = th.load(log_dir,map_location=lambda storage, loc: storage)
        model_cnn.load_state_dict(checkpoint['model_cnn_state_dict'])
        model_flo.load_state_dict(checkpoint['model_flo_state_dict'])
        model.load_state_dict(checkpoint['model_state_dict'])
        optimizer.load_state_dict(checkpoint['optimizer'])
        start_epoch = checkpoint['epoch']
        print('加载 epoch {} 成功！'.format(start_epoch))
        
    gpu_model_cnn = model_cnn.module
    gpu_model_flo = model_flo.module
    gpu_model = model.module
    
    #model = ModelArch(para)
    cpu_model_cnn=Cnn()
    cpu_model_flo=flownet()
    cpu_model = Final() 
    
    cpu_model_cnn.load_state_dict(gpu_model_cnn.state_dict())
    cpu_model_flo.load_state_dict(gpu_model_flo.state_dict())
    cpu_model.load_state_dict(gpu_model.state_dict())
    
    
    data_loss=[]
  # 
    for epoch in trange(start_epoch, epochs, desc='epoch'):
        train_loss=0.
        tic = time.time()
       
        for i, (img1_batch,img2_batch , target_batch) in tqdm(enumerate(loader), desc='batch', total=len(loader)):#last_batch
        
            img1_var = Variable(img1_batch).cuda()
            img2_var = Variable(img2_batch).cuda()
            t_var = Variable(target_batch).cuda()
            data_time = time.time() - tic
            tic = time.time()
            
            optimizer.zero_grad()
           
            out_cnn    = gpu_model_cnn(img1_var)
            #out_cnnmap = model_cnnmap(out_cnn)
            out_flo    = gpu_model_flo(img1_var,img2_var) #, ,last_var ,img2_var
            #out_flomap = model_flomap(out_flo)
            out        = gpu_model(out_cnn, out_flo)
            out1=th.clamp(out.data.cpu(), 3.0228e-04 , 1, out=None)   #3.0228e-04
            #out1=out.data.cpu()
            
            loss = criterion(out, t_var)
            #fwd_time = time.time() - tic²
            #tic = time.time()
            loss.backward()
            #optimizer.step()
           #train_loss += loss.data[0]*bs 
            
            #out_sig1= Accuracy_sig(out1)
           # t_var_sig1=Accuracy_sig1(target_batch*25)
            #out_jiao1, out_acc,out_recall=dif(out_sig1,t_var_sig1)
            
            #print(out_sig1, file=log_file1, flush=True)
            #print(t_var_sig1, file=log_file2, flush=True)
            #print(out_jiao1, file=log_file3, flush=True)
            #val_out1='{:d}, val_acc: {:.6f} , val_recall: {:.6f}'.format(i, th.sum(out_acc)/out.size()[0],th.sum(out_recall
           # print(val_out1, file=log_file5, flush=True) 
            #bkw_time = time.time() - tic
            
            for i1  in   range(out1.size()[0]):
              out_wr=np.squeeze((minmaxscaler(out1).numpy()*255).astype(np.uint8),1)
              target_img=Image.fromarray(out_wr[i1])
              target_img.save('C:/Users/Admin/Desktop/HL/result/246/'+str(i*bs+i1+1)+'.png')
              #target_img.save('F:/experimental result/all/222/'+str(i+1)+'-gt'+'.png')
            #viz.images( minmaxscaler(target_batch.cpu().numpy()), win='gt1')  
            #msg1='{:d}, {:d} ,Train Loss: {:.6f} , loss: {:.7f}'.format(epoch,i,train_loss,loss.data[0] )
            #msg = '[{:03d}|{:05d}/{:05d}] time: data={}, fwd={}, bkw={}, total={}\nloss: {:g}'.format(
               # epoch, i, len(loader), data_time, fwd_time, bkw_time, data_time+fwd_time+bkw_time, loss.data[0])
            viz.images(img1_batch.cpu(), win='gt')  # * 10 abs(out.data.cpu().numpy()) np.maximum
            viz.images( minmaxscaler1(out.data.cpu()), win='cnn1') 
            viz.images( minmaxscaler(target_batch.cpu()), win='target') 
            viz.images( minmaxscaler(out1), win='out') #out.data.cpu().numpy()*1000
            #viz.text(msg, win='log')
            del img1_batch,img1_var,img2_var,t_var, out,out_cnn,out_flo
            th.cuda.empty_cache() 
          
                    
if __name__ == '__main__':
    
    Fire(test)
    