# -*- coding: utf-8 -*-
"""
Created on Tue Nov 10 10:05:00 2020

@author: Administrator
"""

# -*- coding: utf-8 -*-
"""
Created on Thu Sep 10 17:09:53 2020

@author: Administrator
"""


import pdb
import matplotlib.pyplot as plt
import torch.nn.functional as F
import torch as th
import torch.nn as nn
from torch.autograd import Variable
import torchvision.models as models
from torchvision import transforms, utils
from torch.utils.data import Dataset
from torch.utils.data import DataLoader
from PIL import Image
import numpy as np
import torch.optim as optim
import os
import visdom
from torchvision.utils import make_grid
from tqdm import tqdm, trange
from data3 import VRVideo
from  sp_net  import Final ,flownet, Cnn ,Cnn_map,flo_map # spherical_unet
from sconv.module import SphereMSE  #SphericalConv 

BATCH_SIZE = 3
learning_rate = 0.1 
start_epoch = 0
epochs = 30
plot_server='http://127.0.0.1'
plot_port=8097
resume= False #True #
exp_name='final'

test_flag= False

root= 'C:/Users/Admin/Desktop/HL/360video_our' #'E:/360_VRvideo'
frame_h=112
frame_w=224 #448
video_train=6
video_test=2
step_size=6
save_interval=5

viz = visdom.Visdom(server=plot_server, port=plot_port, env=exp_name)

data_transform = transforms.Compose([
        transforms.Resize((112, 224)), #  224, 448
        transforms.ToTensor()
    ])


#train_transforms = transforms.Compose([
 #   transforms.Resize((224,448)),  # 把图片resize为256*256  Random  dCrop
    # transforms.RandomHorizontalFlip(),
#    transforms.ToTensor(), 
    # 将numpy的ndarray或PIL.Image读的图片转换成形状为(C,H, W)的Tensor格式，且/255归一化到[0,1.0]之间
    # cv2:(B,G,R) PIL.Image:(R, G, B)
    # transforms.Normalize((.5, .5, .5), (.5, .5, .5))  # 标准])


def default_loader(root):
    return Image.open(root).convert('RGB')

def minmaxscaler(img_map):
    img_map=np.maximum(img_map, 0)
    min=th.zeros(img_map.size()[0],1,1)
    max=th.zeros(img_map.size()[0],1,1)
    for i11 in range(img_map.size()[0]):
      min[i11]=th.min(img_map[i11])
      max[i11]=th.max(img_map[i11])
      img_map[i11]= (img_map[i11]-min[i11])/(max[i11]-min[i11]+0.00001)
      
    return  img_map 

def Accuracy_sig(he_map):
    block_h=14
    block_w=14
    min=th.zeros(he_map.size()[0],1,1)
    max=th.zeros(he_map.size()[0],1,1)
    for i11 in range(he_map.size()[0]):
      min[i11]=th.min(he_map[i11])
      max[i11]=th.max(he_map[i11])
      he_map[i11]= (he_map[i11]-min[i11])/(max[i11]-min[i11]+0.00001)
      
    a_min=th.zeros(he_map.size()[0],1,int(56/block_h)*int(112/block_w))   
    he_map_sig=th.zeros(int(56/block_h)*int(112/block_w),he_map.size()[0])
    he_map_sig=he_map_sig.int()
    for i2 in range(he_map.size()[0]):
      blocks=1
      for i3 in range(int(56/block_h)):
         for i4 in range(int(112/block_w)):          
           a_min[i2,:,i3*4+i4]=(he_map[i2,:,i3*block_h:(i3+1)*block_h-1, i4*block_w:(i4+1)*block_w-1]).mean()
           if a_min[i2, 0,i3*4+i4] >= 0.2:
             he_map_sig[i3*4+i4,i2]=blocks
           blocks= blocks+1
    
    he_map_sig= th.transpose(he_map_sig,1,0) 
    return he_map_sig
   
def Accuracy_sig1(he_map):
    block_h=14
    block_w=14
    min=th.zeros(he_map.size()[0],1,1)
    max=th.zeros(he_map.size()[0],1,1)
    for i11 in range(he_map.size()[0]):
      min[i11]=th.min(he_map[i11])
      max[i11]=th.max(he_map[i11])
      he_map[i11]= (he_map[i11]-min[i11])/(max[i11]-min[i11]+0.00001)
    a_min=th.zeros(he_map.size()[0],1,int(56/block_h)*int(112/block_w))   
    he_map_sig=th.zeros(int(56/block_h)*int(112/block_w),he_map.size()[0])
    he_map_sig=he_map_sig.int()
    
    for i2 in range(he_map.size()[0]):
      blocks=1
      for i3 in range(int(56/block_h)):
         for i4 in range(int(112/block_w)):          
           a_min[i2,:,i3*4+i4]=(he_map[i2,:,i3*block_h:(i3+1)*block_h-1, i4*block_w:(i4+1)*block_w-1]).mean()
           if a_min[i2, 0,i3*4+i4] != 0:
             he_map_sig[i3*4+i4,i2]=blocks
           blocks= blocks+1
    he_map_sig= th.transpose(he_map_sig,1,0)
    return he_map_sig    

def dif(liA,liB):
    #求交集的两种方式
    #liA=liA.numpy().tolist()
    count_num=0
    reta_sum=[]
    retb_sum=[]
    reta_p=th.zeros(liA.size()[0])
    reta_r=th.zeros(liB.size()[0])
    retA=[]
    for i111 in range(liA.size()[0]):
      
      retA.append(list(set(liA[i111]).intersection(set(liB[i111]))))
      retA[i111] = th.from_numpy(np.array(retA[i111]))
      
      reta_sum.append(liA.size()[1]-liA[i111].numpy().tolist().count(count_num))
      
      retb_sum.append(liB.size()[1]-liB[i111].numpy().tolist().count(count_num))
      reta_p[i111]=((retA[i111].size()[0]-1)/ reta_sum[i111])
      reta_r[i111]=((retA[i111].size()[0]-1)/ retb_sum[i111])
      #reta_p[i111]= th.from_numpy(np.array(reta_p[i111]))
      #reta_r[i111]= th.from_numpy(np.array(reta_p[i111]))
      #retA = [j11 for j11 in liA[i111] if j11 in liB[i111]]
   # retB = list(set(listA).intersection(set(listB)))
     
    return retA,reta_p,reta_r

  
dataset = VRVideo(root,112, 224, video_train, frame_interval=5,transform=data_transform,
                  cache_gt=True, gaussian_sigma=np.pi/20, kernel_rad=np.pi/2, loader=default_loader)
data_loader = DataLoader(dataset, batch_size=BATCH_SIZE, shuffle=False,num_workers=0)

dataset_test = VRVideo(root,112, 224, video_test, frame_interval=5,transform=data_transform,
                  cache_gt=True, gaussian_sigma=np.pi/20, kernel_rad=np.pi/2, loader=default_loader)
data_loader_test = DataLoader(dataset_test, batch_size=BATCH_SIZE, shuffle=False,num_workers=0)


#th.backends.cudnn.enabled = False
model= Final()   
if th.cuda.is_available():
     model=model.cuda()  
   
optimizer = optim.SGD(model.parameters(), lr=learning_rate, momentum=0.9, weight_decay=1e-5)
#torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.1, patience=10, verbose=False, threshold=0.0001, threshold_mode='rel', cooldown=0, min_lr=0, eps=1e-06)
th.optim.lr_scheduler.StepLR(optimizer, step_size, gamma=0.1, last_epoch=-1)
#loss_func = nn.MSELoss()#nn.CrossEntropyLoss()
loss_func = SphereMSE(56, 112).float().cuda()

log_dir='Final'+'-latest.pth.tar'
    
def train(model, data_loader, epoch):
    model.train()
    train_loss = 0
    #for epoch in trange(start_epoch, epochs, desc='epoch'):
        
    for i, (img1_batch, img2_batch, target_batch)  in tqdm(enumerate(data_loader), desc='batch', total=len(data_loader)):
        image1_var =  Variable(img1_batch).cuda() #Variable 是 torch.autograd 中的数据类型，主要用于封装Tensor，进行自动求导
        image2_var=   Variable(img2_batch).cuda()
        target_var =  Variable(target_batch).cuda()
        
        out=model(image1_var,image2_var) 
        
        loss = loss_func(out, target_var)
        
        viz.images( image1_var.data.cpu().numpy(), win='gt') #target_var.astype(np.uint8)
        viz.images( target_var.data.cpu().numpy(), win='gt1') #target_var.astype(np.uint8)
        viz.images(  out.data.cpu().numpy(), win='out') # # out1.astype(np.uint8)
        
        train_loss += loss.data[0]  #item()  #  
        print('{:d}, Train Loss: {:.6f} , loss: {:.6f}'.format(epoch, train_loss,loss.data[0] ))  
            
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        
        if (i + 1) % save_interval == 0:
           state = {'model':model.state_dict(),  'epoch':epoch, 'iter': i}  #'optimizer':optimizer.state_dict(),
           th.save(state, log_dir)
          
        del  image1_var ,image2_var, target_var , out ,loss
        th.cuda.empty_cache() 
        
        
def test(model, test_loader):
    model.eval()
    test_loss = 0
    #correct = 0
    #with torch.no_grad():
    for i, (img1_batch, img2_batch, target_batch)  in tqdm(enumerate(data_loader_test), desc='batch', total=len(data_loader_test)):
        
        image1_var =  Variable(img1_batch).cuda() #Variable 是 torch.autograd 中的数据类型，主要用于封装Tensor，进行自动求导
        image2_var=   Variable(img2_batch).cuda()
        target_var =  Variable(target_batch).cuda()
        
        optimizer.zero_grad()
        out=model(image1_var,image2_var)     
        loss = loss_func(out, target_var)
        
        viz.images( image1_var.data.cpu().numpy(), win='gt') #target_var.astype(np.uint8)
        viz.images( target_var.data.cpu().numpy(), win='gt1') #target_var.astype(np.uint8)
        viz.images(  out.data.cpu().numpy(), win='out') # # out1.astype(np.uint8)
        
        test_loss += loss.data[0]  #item()  #  
        print(' Train Loss: {:.6f} , loss: {:.6f}'.format( test_loss, loss.data[0] ))  
            
       
          
       

def main():
   
    
        
    if os.path.exists(log_dir):
        checkpoint = th.load(log_dir)
        model.load_state_dict(checkpoint['model'])
        #optimizer.load_state_dict(checkpoint['optimizer'])
        start_epoch = checkpoint['epoch']
        print('加载 epoch {} 成功！'.format(start_epoch))
    else:
        start_epoch = 0
        print('无保存模型，将从头开始训练！')
        
    if test_flag:
        # 加载保存的模型直接进行测试机验证，不进行此模块以后的步骤
        checkpoint = th.load(log_dir)
        model.load_state_dict(checkpoint['model'])
        #optimizer.load_state_dict(checkpoint['optimizer'])
        start_epoch = checkpoint['epoch']
        test(model, data_loader_test)
        #return
    
    for epoch in trange(start_epoch, epochs, desc='epoch'):
        
        train(model, data_loader, epoch)
        #test(model,  data_loader_test)
        # 保存模型
       
         
    
if __name__ == "__main__":
    
      main()