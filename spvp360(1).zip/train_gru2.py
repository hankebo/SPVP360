# -*- coding: utf-8 -*-
"""
Created on Mon Dec 21 10:01:45 2020

@author: Admin
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Nov 23 11:18:01 2020

@author: Administrator
"""
from torch import nn
import numpy as np
import torch as th
from data4 import VRVideo
import torchvision.transforms as tf
from torch.utils import data as tdata
import torch.optim as optim
from torch.autograd import Variable
from argparse import ArgumentParser
from fire import Fire
from tqdm import trange, tqdm
import visdom
import time

from  sp_net  import Final ,flownet, Cnn ,Cnn_map,flo_map 
from net_gru  import fore_map ,forefin_map
#from  sp_net1  import Final  # spherical_unet
from sconv.module import SphereMSE  #SphericalConv 
import os
#import  pdb
  
def minmaxscaler(img_map):
    #img_map=th.clamp(img_map, 2.0228e-04, 1, out=None)
    min=th.zeros(img_map.size()[0],1,1)
    max=th.zeros(img_map.size()[0],1,1)
    for i11 in range(img_map.size()[0]):
      min[i11]=th.min(img_map[i11])
      max[i11]=th.max(img_map[i11])
      img_map[i11]= (img_map[i11]-min[i11])/(max[i11]-min[i11]+0.00001)
      
    #img_map=np.maximum(img_map, 0)
    #img_map=abs(img_map)
    #min=np.amin(img_map)
    #max=np.amax(img_map)
    #img_map= (img_map-min)/(max-min+0.00001)
    #np.where(img_map > 0.5,  img_map, 0)
    #img_map=np.maximum(img_map, 0.5 )
    return  img_map 
    
def minmaxsmap(img_m):
    
    #img_m=th.clamp(img_m, 3.0228e-04, 1, out=None)
    min=th.zeros(img_m.size()[0],1,1)
    max=th.zeros(img_m.size()[0],1,1)
    for i11 in range(img_m.size()[0]):
      min[i11]=th.min(img_m[i11])
      max[i11]=th.max(img_m[i11])
      img_m[i11]= (img_m[i11]-min[i11])/(max[i11]-min[i11]+0.00001)
   
    a_max=th.zeros(img_m.size()[0],1,16)
   
    a1_max=th.zeros(img_m.size()[0],1,1)
  
    for i2 in range(img_m.size()[0]):
      for i3 in range(4):
         for i4 in range(4):          
           a_max[i2,:,i3*4+i4]=th.max(img_m[i2,:,i3*14:(i3+1)*14-1, i4*28:(i4+1)*28-1])
      a1_max=th.max(img_m[i2])
     
      
    a_max_sum=th.sum(a_max,2)/16
    a_factor= th.squeeze((a_max_sum-a1_max)*(a_max_sum-a1_max))
    
    for i12 in range(img_m.size()[0]):
     img_m[i12]=img_m[i12]*a_factor[i12]
    
    return img_m 

def Accuracy_sig(he_map):
    min=th.zeros(he_map.size()[0],1,1)
    max=th.zeros(he_map.size()[0],1,1)
    for i11 in range(he_map.size()[0]):
      min[i11]=th.min(he_map[i11])
      max[i11]=th.max(he_map[i11])
      he_map[i11]= (he_map[i11]-min[i11])/(max[i11]-min[i11]+0.00001)
    a_min=th.zeros(he_map.size()[0],1,16)   
    he_map_sig=th.zeros(he_map.size()[0],1,1)
   
    for i2 in range(he_map.size()[0]):
      for i3 in range(int(56/14)):
         for i4 in range(int(112/28)):          
           a_min[i2,:,i3*4+i4]=th.min(he_map[i2,:,i3*14:(i3+1)*14-1, i4*28:(i4+1)*28-1])
           #if a_min[i2,:,i3*4+i4]>=0.1:
             #he_map_sig[i2,0,0]=he_map_sig[i2,0,0]+1
    he_map_sig = th.gt(a_min,0.5)
             #he_map_sig[i2,0,i3*4+i4]==1
             
    return he_map_sig
   
   
def creatdataset(data,target_data):
    #look_back=5
    seg_len=3
    #in_user=5
    #x1=th.zeros(int(len(data)/look_back),in_user,1,112,224 ) # data.size()[1:]
    #x2=th.zeros(int(len(data)/look_back-seg_len),in_user,seg_len,1,112,224)
    data_x=[]
    data_y=[]
    #data_saliency=[]
    #x= th.split(data, in_user,dim=0)
    #for j in range(int(len(data)/look_back)):
       # x1[j]=x[j]
    #x1 = x1.permute(1, 0, 2, 3, 4)
    for i in range(len(data)- seg_len): #-look_back
     #for j in range(5):
         data_x.append(data[i:i+ seg_len])
         #x2[i]=x1[:, i:i+ seg_len, :, :, :]
         data_y.append(target_data[i+seg_len])
         #data_saliency.append(saliency[i+seg_len])
    #x2 = x2.permute(1, 0, 2, 3, 4,5) 
#   for k in range(in_user):    
        #data_x.append(x2[k])  #data[i:i+look_back] split 1[:, i:i+ seg_len, :, :, :]
      
    return data_x, data_y#, data_saliency

def train(
        root='C:/Users/Admin/Desktop/HL/360video_our',  #E:/360_VRvideo','F:/360VRvideo', #360_Saliency_dataset_2018ECCV
        bs=24, #28
        lr=0.1,
        epochs=100,
        clear_cache=False,
        plot_server='http://127.0.0.1',
        plot_port=8097,
        save_interval=5,
        resume=False,
        resume_saliency=True,  #True False
        height =112,
        width = 224,
        start_epoch=0,
        exp_name='final',
        step_size=10,
        test_mode=True #False,
        
):
    # pynvml.nvmlInit()
    viz = visdom.Visdom(server=plot_server, port=plot_port, env=exp_name)

    transform = tf.Compose([
        tf.Resize((height, width)), #128, 256  #shuffle=true 数据集打乱     
        tf.ToTensor()
    ])
    dataset = VRVideo(root,height, width,4, frame_interval=5, cache_gt= True, transform=transform, gaussian_sigma=np.pi/20, kernel_rad=np.pi/7)
    #print(dataset)  #128, 256,
    if clear_cache:
        dataset.clear_cache()
    loader = tdata.DataLoader(dataset, batch_size=bs, shuffle= False , num_workers=0, pin_memory=False )#True TrueTrue
    #print(type(loader))
    
    
    
    model=fore_map()
    #model_fore=forefin_map()
    model=model.cuda()
    #model_fore=model_fore.cuda()
    
    optimizer = optim.SGD(model.parameters(), lr, momentum=0.9, weight_decay=1e-5)  #优化器
    th.optim.lr_scheduler.StepLR(optimizer, step_size, gamma=0.1, last_epoch=-1)
    #th.optim.torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, 'min')
    #pmodel =model#.cuda()
    #pmodel = nn.DataParallel(model).cuda()
    
    criterion = SphereMSE(int(height/2),int( width/2)).float().cuda()    #损失函数128,256
    
    log_dir='for_net_gru6.pth.tar'
    if os.path.exists(log_dir):
        checkpoint = th.load(log_dir)
        #model_fore.load_state_dict(checkpoint['model_fore_state_dict'])
        #optimizer.load_state_dict(checkpoint['optimizer'])
        start_epoch = checkpoint['epoch']
        print('加载 epoch {} 成功！'.format(start_epoch))
    else:
        start_epoch = 0
        print('无保存模型，将从头开始训练！')
    #if resume:
     #   ckpt = th.load('for_net_gru.pth.tar' ) #+ exp_name
       # model.load_state_dict(ckpt['state_dict'])   #'''应用到网络结构中'''
      #  start_epoch = ckpt['epoch']
    log_file = open( 'final6.txt', 'a+')
   
    
    model_cnn=Cnn()
   # model_cnnmap=Cnn_map()
    model_flo=flownet()
    #model_flomap=flo_map()
    model1 = Final()
    model_cnn= model_cnn.cuda()
    #model_cnnmap=model_cnnmap.cuda()
    model_flo=model_flo.cuda()
    #model_flomap=model_flomap.cuda()
    model1 =model1.cuda()
    if resume_saliency:  
        ckpt = th.load('model_final1.pth.tar' ) #+ exp_name
        model1.load_state_dict(ckpt['model_state_dict'])   #'''应用到网络结构中'''
        #start_epoch = ckpt['epoch']
        
    data_loss=[]   
   
    seg_len=3
    #in_user=5
    for epoch in trange(start_epoch, epochs, desc='epoch'):
        train_loss=0.
        tic = time.time()
        for i, (img1_batch,img2_batch,input_m_batch,target_batch) in tqdm(enumerate(loader), desc='batch', total=len(loader)):#last_batch ,img2_batch , target_batch
        
            img1_var = Variable(img1_batch).cuda()
            img2_var = Variable(img2_batch).cuda()
            #t_var = Variable(target_batch)#.cuda()
            out_cnn    = model_cnn(img1_var)
            #out_cnnmap = model_cnnmap(out_cnn)
            out_flo    = model_flo(img1_var,img2_var) #, ,last_var ,img2_var
            #out_flomap = model_flomap(out_flo)
            out1        = model1(out_cnn, out_flo)
            data_time = time.time() - tic
            tic = time.time()
            
            img_x_batch1=th.zeros(int(input_m_batch.size()[0]-seg_len),seg_len,1,int(height/2),int(width/2)) #5 表示bitch size， 3表示seq_len
            img_y_batch1=th.zeros(int(input_m_batch.size()[0]-seg_len),1,int(height/2),int(width/2))
            out_saliency=th.zeros(int(input_m_batch.size()[0]-seg_len),1,int(height/2),int(width/2))
            #out1=model1(img1_var)
            out_saliency=out1[seg_len:input_m_batch.size()[0]]
            
            img_x,img_y =creatdataset(input_m_batch,target_batch) #
            
            for i1 in range(int(input_m_batch.size()[0]-seg_len)):
               img_x_batch1[i1]= img_x[i1] 
               img_y_batch1[i1]= img_y[i1]
               #out_saliency[i1]=img_saliency[i1]
            #img_x_batch1=th.squeeze(img_x_batch1)
            
            img_x_int=Variable(img_x_batch1).cuda()
            img_y_int=Variable(img_y_batch1).cuda()
          
            
            out=model(img_x_int) #last_state_list1#+m*saliency
            
            out_vi=th.clamp(out.data.cpu(), 0, 1, out=None)            
            out_vive=minmaxsmap( out_vi) #.numpy()
            
            out_s=th.clamp(out_saliency.data.cpu(), 3.0228e-04, 1, out=None) 
            out_sm=minmaxsmap(out_s) #.numpy(
              
            OUT1= out_vive+ out_sm
            
            #OUT=model_fore(out, out_saliency)
            
            OUT1_var=Variable(OUT1,requires_grad=True).cuda()
            optimizer.zero_grad()
            
            
            #OUT1_sig=Accuracy_sig(OUT1)
            #img_y_batch1_sig=Accuracy_sig(img_y_batch1)
            #Accuracy=th.zeros(img_x_int.size()[0],1,1)
            
            
           # Accuracy= OUT1_sig/img_y_batch1_sig
            
            loss = criterion(OUT1_var,img_y_int)
            #fwd_time = time.time() - tic
            tic = time.time()
            loss.backward()
            optimizer.step()
            
           
            train_loss += loss.data[0]#*(input_m_batch.size()[0]-seg_len)  
               
            
            
            
           
            #bkw_time = time.time() - tic
          
           
              
            msg1='{:d}, {:d}, Train Loss: {:.6f} , loss: {:.6f}'.format(epoch,i, train_loss,loss.data[0] )
              
               
            #msg = '[{:03d}|{:05d}/{:05d}] time: data={}, fwd={}, bkw={}, total={}\nloss: {:g}'.format(
            #   epoch, i, len(loader), data_time, fwd_time, bkw_time, data_time+fwd_time+bkw_time, loss.data[0])
            viz.images(img1_batch.cpu().numpy(), win='in1')
            viz.images( minmaxscaler(input_m_batch.cpu()), win='gt') 
            viz.images(minmaxscaler(out_s), win='in')# * 10 abs(out.data.cpu().numpy()) np.maximum
            viz.images(minmaxscaler(target_batch.cpu()), win='gt1') 
            viz.images(minmaxscaler(out_vi), win='out') #out.data.cpu().numpy()*1000
            viz.images(minmaxscaler(OUT1), win='ot1')
            #viz.text(msg, win='log')
            #th.cuda.empty_cache() 
            if (i+1) % 20 == 0:
              print(msg1, file=log_file, flush=True)
            #print(msg, flush=True)

            tic = time.time()
           
            if (i + 1) % save_interval == 0:
                
                #state_dict = model.state_dict()
                #ckpt = dict(epoch=epoch, iter=i, state_dict=state_dict)
                th.save({'epoch': epoch, 'iter': i,
                          'model': model},  'for_net_gru6.pth.tar') # + exp_name 

            del img1_batch,img2_batch,input_m_batch,target_batch,img_x_int,img_y_int,img1_var,img2_var
            OUT1,out, out1, out_cnn,out_cnn,out_saliency
            th.cuda.empty_cache()
        data_loss.append(train_loss)
        viz.line( Y=np.array([data_loss[epoch]]), X=np.array([epoch]),update='append', opts={'title':'loss'}, win='loss_win')
            
if __name__ == '__main__':
    
    Fire(train)
  
