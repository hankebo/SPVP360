# -*- coding: utf-8 -*-
"""
Created on Tue Sep 29 21:51:29 2020

@author: Administrator
"""

# -*- coding: utf-8 -*-
"""
Created on Wed Jul 29 11:20:04 2020

@author: Administrator
"""
import  torch
import visdom
import numpy as np
import torch as th
from sconv.module import SphericalConv#, SphereMSE
from torch import nn
from torch.autograd import Variable
from torchvision.utils import make_grid
from gru  import ConvLSTMCell
from GRUcell  import ConvGRU 


plot_server='http://127.0.0.1'
plot_port=8097
resume= False
exp_name='final'

viz = visdom.Visdom(server=plot_server, port=plot_port, env=exp_name)

class Cnn(nn.Module):
    def __init__(self):
        super(Cnn, self).__init__()
        self.conv1 = SphericalConv(3, 16, np.pi/32, kernel_size=(3, 3), stride=(1, 1), kernel_sr=None)
        self.bn1 = nn.BatchNorm2d(16)     #数据的归一化处理,对tensor求均值和方差
        self.relu1 = nn.ReLU(inplace=True)  #非线性激励函数
        self.pool1 = nn.MaxPool2d(2, 2)
        
        self.conv2 = SphericalConv(16, 32, np.pi/32, kernel_size=(3, 3),stride=(1, 1), kernel_sr=None)
        self.bn2 = nn.BatchNorm2d(32)
        self.relu2 = nn.ReLU(inplace=True)
        self.pool2 = nn.MaxPool2d(2, 2)
        
        self.conv3 = SphericalConv(32, 64, np.pi/16, kernel_size=(3, 3), stride=(1, 1), kernel_sr=None )
        self.bn3 = nn.BatchNorm2d(64)
        self.relu3 = nn.ReLU(inplace=True)
        self.pool3 = nn.MaxPool2d(2, 2)
        
        self.conv4 = SphericalConv(64, 128, np.pi/2,  kernel_size=(3, 3), stride=(1, 1), kernel_sr=None )
        self.bn4 = nn.BatchNorm2d(128)
        self.relu4 = nn.ReLU(inplace=True)
        self.pool4 = nn.MaxPool2d(2, 2)
        
        self.conv5 = SphericalConv(128, 256, np.pi/2, kernel_size=(3, 3), stride=(1, 1),  kernel_sr=None)
        self.bn5 = nn.BatchNorm2d(256)
        self.relu5 = nn.ReLU(inplace=True)
        self.pool5 = nn.MaxPool2d(2, 2)

        #self.conv6 = SphericalConv(256, 512, np.pi/2, kernel_size=(1, 3), stride=(1, 1), kernel_sr=None)
        #self.bn6 = nn.BatchNorm2d(512)
        #self.relu6 = nn.ReLU(inplace=True)
        #self.pool6 = nn.MaxPool2d(2, 2)
        
        self.conv7 = SphericalConv(256, 512, np.pi, kernel_size=(3, 3), stride=(1, 1), kernel_sr=None)  #torch.Size([2, 512, 3, 7])
        self.conv8 = SphericalConv(512, 512, np.pi, kernel_size=(3, 3), stride=(1, 1), kernel_sr=None)
        self.conv9 = SphericalConv(512, 512, np.pi, kernel_size=(3, 3), stride=(1, 1), kernel_sr=None)
        #self.per1 = th.permute(512,(0,3,1,2))
       
        self.fc1 =  nn.Linear(50176,256)  #10752
        self.fc2 =  nn.Linear(256,4096)
        self.fc3 =  nn.Linear(4096,2940)
        self.fc3_1 = nn.Upsample(size=(14,28))
        
        self.conv9_1 =  SphericalConv(512, 128, np.pi, kernel_size=(1,1), stride=(1, 1),  kernel_sr=None)
        self.up9_1 = nn.Upsample(size=(14,28))
        self.conv5_1 =  SphericalConv(256, 128, np.pi/2, kernel_size=(1,1), stride=(1, 1),  kernel_sr=None)
        self.conv4_1 =  SphericalConv(128, 128, np.pi/2, kernel_size=(1,1), stride=(1, 1),  kernel_sr=None )
        self.dp4_1 = nn.MaxPool2d(kernel_size=2)
    def forward(self, image):
        
        c1 = self.conv1(image) #th.cat([image, last], dim=1
        b1 = self.bn1(c1)
        r1 = self.relu1(b1)
        p1 = self.pool1(r1)

        c2 = self.conv2(p1)
        b2 = self.bn2(c2)
        r2 = self.relu2(b2)  #非线性激活层即保留大于0的值，即保留特征比较好的值，将特征小于0的值舍去
        p2 = self.pool2(r2)

        c3 = self.conv3(p2)
        b3 = self.bn3(c3)
        r3 = self.relu3(b3)
        p3 = self.pool3(r3)
        
        c4 = self.conv4(p3)
        b4 = self.bn4(c4)
        r4 = self.relu4(b4)
        p4 = self.pool4(r4)

        c5 = self.conv5(p4)
        b5 = self.bn5(c5)
        r5 = self.relu5(b5)
        p5 = self.pool5(r5)
        
        #c6 = self.conv6(p5)
        #b6 = self.bn6(c6)
        #r6 = self.relu6(b6)
        #p6 = self.pool6(r6)
        
        c7 = self.conv7(p5)
        c8 = self.conv8(c7)
        c9 = self.conv9(c8)  #torch.Size([2, 512, 3, 7])
        #print(c8.size())
        
       # = x.view(-1, 16 * 5 * 5) # view  和reshape功能一样
        #print(c6.size())
        #temp_conv = c9.permute(1,0,2,3).contiguous()#th.permute(c9,(0,3,1,2))
        #print(c9.permute(0,3,1,2).size())
        
        temp_view =  c9.view(c9.size(0), -1) #temp_view  temp_conv
        #print(temp_view.size())
        fc1 = self.fc1(temp_view)
        fc2 = self.fc2(fc1)
        fc3 = self.fc3(fc2)
        bs=fc3.size()
        
        highFeature=fc3.resize(bs[0],30,7,14)  #fc3,[fc3.getshape()[0].value,7,14,-1],不知道对不对reshape
        newhighFeature=self.fc3_1(highFeature)
        #print(newhighFeature.size())  
        
        c9_1=self.conv9_1(c9)
        newd9_1=self.up9_1(c9_1)
        c5_1= self.conv5_1(c5)
        c4_1= self.conv4_1(c4)
        newc4_1= self.dp4_1(c4_1)
        #print(p6.size())
        #print(d9_1.size())
        #print(c5_1.size())
        #print(newc4_1.size())
        #tempsize=c5.size()#.getshape.as_list()
       
       # tempsize=conv7.get_shape().as_list() 
        #newconv5=c9_1([[2],[3]]).resize([tempsize[2],tempsize[3]]) #th.image.resize_images
    
        #newconv7=th.image.resize_images(c5_1,[tempsize[2],tempsize[3]]) 
        #newconv9=th.image.resize_images(c9_1,[tempsize[2],tempsize[3]]) 
        
        FeatureMap= th.cat([ newd9_1 ,c5_1, newc4_1, newhighFeature],1) #newhighFeature.size[1, 414, 14, 28],
        #print(FeatureMap.size())
        G=c5_1.size()
        weight_mask = Variable(self.get_centermask(G)) #type(FeatureMap) # #,dtype=FeatureMap.dtype
        # nn.init.constant()
        weight_mask=Variable(weight_mask)
        
        FeatureMap=FeatureMap*weight_mask #将二者相乘，得到的仍是（1,28,28,542-128）的特征映射
        #print(FeatureMap.size())
        return FeatureMap
    
        #viz.images(FeatureMap.data.cpu().numpy(), win='gt') 
       
    def get_centermask(self,G): # shape[batchsize, height, width, channals]
        width = G[3]
        heigh = G[2]
        midw = width//2
        midh = heigh//2
        distmatrix = np.zeros([heigh, width])
        for x in range(width):
           for y in range(heigh):
              value = np.sqrt((x - midw)**2+(y - midh)**2)
              distmatrix[x, y] = value
              distmatrix = distmatrix / np.max(distmatrix)
              distmatrix = 1 -  distmatrix
              distmatrix = distmatrix[np.newaxis,...,np.newaxis]
              distmatrix=torch.Tensor(distmatrix)
              distmatrix=distmatrix.permute(0,3,1,2)
              # distmatrix = tf.expand_dims(distmatrix, 0)
              # distmatrix = tf.expand_dims(distmatrix, 3)
              # for a in range(f_shape[0]):
              #   for b in range(f_shape[3]):
              #     mask[a, :, :, b] = distmatrix
              return distmatrix     
    
#net1= Cnn()
#print(net1)   


       


   
class flownet(nn.Module):
    def __init__(self):
        super(flownet, self).__init__()
        self.conv1 = SphericalConv(6, 64, np.pi/32, kernel_size=(7, 7), stride=(2, 2), kernel_sr=None)
        self.bn1   = nn.BatchNorm2d(64)
        self.relu1 = nn.ReLU(inplace=True)
        
        self.conv2 = SphericalConv(64, 128, np.pi/32, kernel_size=(5, 5), stride=(2, 2), kernel_sr=None)
        self.bn2   = nn.BatchNorm2d(128)
        self.relu2 = nn.ReLU(inplace=True)
        
        self.conv3 = SphericalConv(128, 256, np.pi/16, kernel_size=(5, 5), stride=(2, 2), kernel_sr=None)
        self.bn3   = nn.BatchNorm2d(256)
        self.relu3 = nn.ReLU(inplace=True)
        
        self.conv3_1 =SphericalConv(256, 256, np.pi/4, kernel_size=(3, 3), stride=(1, 1), kernel_sr=None )
        self.bn3_1   = nn.BatchNorm2d(256)
        self.relu3_1 = nn.ReLU(inplace=True) #第四个卷积块  3*3*256 
        
        self.conv4 = SphericalConv(256, 512, np.pi/2, kernel_size=(3, 3), stride=(2, 2), kernel_sr=None )
        self.bn4   = nn.BatchNorm2d(512)
        self.relu4 = nn.ReLU(inplace=True)
        
        self.conv4_1 = SphericalConv(512, 512, np.pi/2, kernel_size=(3, 3), stride=(1, 1), kernel_sr=None )
        self.bn4_1   = nn.BatchNorm2d(512)
        self.relu4_1 = nn.ReLU(inplace=True)   
        
        self.conv5 = SphericalConv(512, 512, np.pi/2, kernel_size=(3, 3), stride=(2, 2), kernel_sr=None )
        self.bn5   = nn.BatchNorm2d(512)
        self.relu5 = nn.ReLU(inplace=True)
        
        self.conv5_1 = SphericalConv(512, 512, np.pi/2, kernel_size=(3, 3), stride=(1, 1), kernel_sr=None )
        self.bn5_1   = nn.BatchNorm2d(512)
        self.relu5_1 = nn.ReLU(inplace=True)
        
        self.conv5_1_1 = SphericalConv(512, 128, np.pi/2, kernel_size=(3, 3), stride=(1, 1), kernel_sr=None )
        self.bn5_1_1   = nn.BatchNorm2d(128)
        self.relu5_1_1 = nn.ReLU(inplace=True)
        self.w5_1_1 = nn.Upsample(size=(14,28))
       
        self.conv4_1_1 = SphericalConv(512, 128, np.pi/2, kernel_size=(3, 3), stride=(1, 1), kernel_sr=None )
        self.bn4_1_1   = nn.BatchNorm2d(128)
        self.relu4_1_1 = nn.ReLU(inplace=True)   
        
        self.conv3_1_1 = SphericalConv(256, 128,np.pi/2, kernel_size=(3, 3), stride=(1, 1), kernel_sr=None )
        self.bn3_1_1   = nn.BatchNorm2d(128)
        self.relu3_1_1 = nn.ReLU(inplace=True)
        self.pool3_1_1 = nn.MaxPool2d(2, 2)
        
    def forward(self, x1, x2): 
        
        input = th.cat([x1, x2], dim=1)
        a1 =  self.conv1(input)
        h1 =  self.bn1(a1)
        w1 =  self.relu1(h1)
      # d1 =  self.conv_mask(w1,mask)
       
        a2 =  self.conv2(w1)
        h2 =  self.bn2(a2)
        w2 =  self.relu2(h2)
        #d2 =  self.conv_mask(w2,mask)
        
        a3 =  self.conv3(w2)     #a3.size[4, 256, 28, 56]
        h3 =  self.bn3(a3)
        w3 =  self.relu3(h3)
        #d3 =  self.conv_mask(w3,mask)
        
        a3_1 =  self.conv3_1(w3)  #a3_1.size[4, 256, 28, 56]
        h3_1 =  self.bn3_1(a3_1)
        w3_1 =  self.relu3_1(h3_1)
        #d3_1 =  self.conv_mask(w3_1,mask)
        
        a4 =  self.conv4(w3_1)  #a4.size[4, 256, 14, 28]
        h4 =  self.bn4(a4)
        w4 =  self.relu4(h4)
        #d4 =  self.conv_mask(w4,mask)
        
        a4_1 =  self.conv4_1(w4)   #a4_1.size[4, 256, 14, 28]
        h4_1 =  self.bn4_1(a4_1)
        w4_1 =  self.relu4_1(h4_1)
       # d4_1 =  self.conv_mask(w4_1,mask)
        
        a5 =  self.conv5(w4_1)   #a5.size[4, 256, 7, 14]
        h5 =  self.bn5(a5)
        w5 =  self.relu5(h5)
        #d5 =  self.conv_mask(w5,mask)
        
        a5_1 =  self.conv5_1(w5)  #a5_1.size[4, 256, 7, 14]
        h5_1 =  self.bn5_1(a5_1)
        w5_1 =  self.relu5_1(h5_1)
        #d5_1 =  self.conv_mask(w5_1,mask)
        #print(w1.size())
        #print(w2.size())
        #print(w3.size())
        #print(w3_1.size())
        #print(w4.size())
        #print(w5_1.size())
        out_cat_size=a4.size()  #a4.size[4, 256, 14, 28]
        
        a5_1_1 =  self.conv5_1_1(w5_1)
        h5_1_1 =  self.bn5_1_1(a5_1_1)
        w5_1_1 =  self.relu5_1_1(h5_1_1)
        
        a4_1_1 =  self.conv4_1_1(w4_1)
        h4_1_1 =  self.bn4_1_1(a4_1_1)
        w4_1_1 =  self.relu4_1_1(h4_1_1)
        
        a3_1_1 =  self.conv3_1_1(w3_1)
        h3_1_1 =  self.bn3_1_1(a3_1_1)
        w3_1_1 =  self.relu3_1_1(h3_1_1)
        
        conv_5_1_cat= self.w5_1_1(w5_1_1)         #@th.image.resize_images(w5_1_1,[out_cat_size[1],out_cat_size[2]])
        #将第八个卷积块得到的特征映射的大小调整为14*28
        conv_4_1_cat= w4_1_1  #th.image.resize_images(w4_1_1,[out_cat_size[1],out_cat_size[2]])
        #将第六个卷积块得到的特征映射的大小调整为14*28
        conv_3_1_cat= self.pool3_1_1(w3_1_1)  #th.image.resize_images(w3_1_1,[out_cat_size[1],out_cat_size[2]])
        #//将第四个卷积块得到的特征映射的大小调整为14*28
        #print( conv_5_1_cat.size())
        #print( conv_4_1_cat.size())
        #print( conv_3_1_cat.size())
        concat_out=th.cat([conv_5_1_cat,conv_4_1_cat,conv_3_1_cat],1 )#name='FNconcat_out'
        
        
        return   concat_out
    
    def conv_mask(self, w, mask):
       tempsize = w.get_shape().as_list()
       w_mask = th.image.resize_images(mask, [tempsize[1], tempsize[2]])
       print(w_mask.get_shape().as_list())
       
       return w * w_mask   
   
#net2= flownet()
#print(net2)   

class Coarse_salmap(nn.Module):
    def __init__(self):
        super(Coarse_salmap, self).__init__()
       
        self.conv11 = SphericalConv(414, 256, np.pi/2, kernel_size=(3,3), kernel_sr=None, stride=(1,1), bias=False) #414 414
        #self.bn11   = nn.BatchNorm2d(256)
        #self.relu11 = nn.ReLU(inplace=True)
        self.conv12 = SphericalConv(256, 256, np.pi/2, kernel_size=(1,1), kernel_sr=None, stride=(1,1), bias=False)
        self.conv13 = SphericalConv(256, 128, np.pi/3, kernel_size=(3,3), kernel_sr=None, stride=(1,1), bias=False)
        self.conv14 = SphericalConv(128, 128, np.pi/3, kernel_size=(1,1), kernel_sr=None, stride=(1,1), bias=False)
       
        
        self.deconv1 = nn.ConvTranspose2d(128,64, kernel_size=4,stride=2)
        self.deconv2 = nn.ConvTranspose2d(64,1, kernel_size=4, stride=2)
        self.de = nn.Upsample((124,236))#,mode='bilinear'
        #self.deconv3 = nn.ConvTranspose2d(16,1, kernel_size=4, stride=2)
        #self.bn13   = nn.BatchNorm2d(1)
        #self.relu13 = nn.ReLU(inplace=True)
    def forward(self, image3): 
       model4 = Cnn()
       #model3=model3#.cuda()
       feature = model4(image3)
      
       c11 = self.conv11(feature)
       #b11 = self.bn11(c11)
       #r11 = self.relu11(b11)
       c12 = self.conv12(c11)
       #print(c11)
       #print(c12)
       c13 = self.conv13(c12)
       c14 = self.conv14(c13)
       
       g1 = self.deconv1(c14)
       #print(g1)
       g2 = self.deconv2(g1)
       g3 = self.de(g2)
       #g31= self.bn13(g3)
       #g32= self.relu13(g3)
       #print(g1.size())
       #print(g2.size())
       #print(g3.size())
       return  g3   
        

class  Final(nn.Module):   
     def __init__(self):
        super(Final, self).__init__()
        
        #self.FeatureMap=  Cnn(414) 
        self.lastconv1 =  SphericalConv(414+384, 512,np.pi/2, kernel_size=(3, 3), stride=(1, 1), kernel_sr=None )
        self.lastconv2 =  SphericalConv(512, 512, np.pi/2, kernel_size=(3, 3), stride=(1, 1), kernel_sr=None )        
        self.lastconv3 =  SphericalConv(512, 256, np.pi/2, kernel_size=(3, 3), stride=(1, 1), kernel_sr=None )
        self.lastconv4 =  SphericalConv(256, 128, np.pi/2, kernel_size=(3, 3), stride=(1, 1), kernel_sr=None )
     def forward(self, image1, image2):
        model2=flownet()
        #model2=model2#.cuda() 
        self.concat_out = model2(image1,image2)  #th.cat([image1, image2], 1)
        
        model1=Cnn()
        #model1=model1#.cuda()
        self.FeatureMap = model1(image1) 
        
        cat1 = self.FeatureMap
        cat2 =  self.concat_out
        MyFeature = th.cat([cat1,cat2], 1)  
        
        lastconv1 =  self.lastconv1(MyFeature)
        lastconv2 =  self.lastconv2(lastconv1)
        lastconv3 =  self.lastconv3(lastconv2)
        lastconv4 =  self.lastconv4(lastconv3)
       
        return lastconv4 
    
class salmap(nn.Module):
    def __init__(self):
        super(salmap, self).__init__()
        
        self.deconv1 = nn.ConvTranspose2d(128,64, kernel_size=4,stride=2)
        self.deconv2 = nn.ConvTranspose2d(64,1, kernel_size=4, stride=2)
        #self.deconv3 = nn.ConvTranspose2d(16,1, kernel_size=4, stride=2)
        #self.bn13   = nn.BatchNorm2d(1)
        #self.relu13 = nn.ReLU(inplace=True)
    def forward(self, image1,image2):  #image1,image2
    
        model4=Final()
        last_feature=model4(image1,image2)
        g1 = self.deconv1(last_feature)
        g2 = self.deconv2(g1)
        
        return g2
        
    
    
    
    
class saliency_map(nn.Module):
    def __init__(self):
        super(saliency_map, self).__init__()
        
        self.deconv1 = nn.ConvTranspose2d(128,64, kernel_size=4,stride=2)
        self.deconv2 = nn.ConvTranspose2d(64,1, kernel_size=4, stride=2)
        #self.deconv3 = nn.ConvTranspose2d(16,1, kernel_size=4, stride=2)
        #self.bn13   = nn.BatchNorm2d(1)
        #self.relu13 = nn.ReLU(inplace=True)
    def forward(self, last_feature): #image1,image2
       #model4=Final()
       #model3=model3#.cuda()
       #last_feature=model4(image1,image2) 
       #use_gpu = torch.cuda.is_available()
       #if use_gpu:
       #    dtype = torch.cuda.FloatTensor # computation in GPU
       #else:
       dtype = torch.FloatTensor

       height =14
       width = 28
       channels = 128
       hidden_dim = [128, 128]
       kernel_size = (3,3) # kernel size for two stacked hidden layer
       num_layers = 2 # number of stacked hidden layer 
       model1111 = ConvGRU(input_size=(height, width),
                    input_dim=channels,
                    hidden_dim=hidden_dim,
                    kernel_size=kernel_size,
                    num_layers=num_layers,
                    dtype=dtype,
                    batch_first=True,
                    bias = True,
                    return_all_layers = False)
       
       last_feature=th.unsqueeze(last_feature,1)
        
       layer_output_list, last_state_list =  model1111( last_feature ) 
       layer_output = layer_output_list[0]
       g1 = self.deconv1(layer_output[:,0,:,:,:])
       g2 = self.deconv2(g1)
      # g3 = self.deconv3(g2)
       #g31= self.bn13(g3)
       #g33= self.relu13(g3)
       #print(g1.size())
       #print(g2.size())
       #print(g3.size())
       return  g2       

        

 
   

    
    